#!/usr/bin/env python3
"""
Simple test script for the Cursor + PowerShell setup.
"""

def main():
    print("🎉 Hello from Python!")
    print("✅ Cursor + PowerShell setup is working!")
    print("🚀 Ready for development!")

if __name__ == "__main__":
    main()