# setup-cursor-portable.ps1
# Portable version - run from anywhere without installation

# [Full portable script content here - embedded in release]
